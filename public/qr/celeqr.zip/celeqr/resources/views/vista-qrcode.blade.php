<img src="{{ $qrCodeDataUri }}" alt="Código QR">
