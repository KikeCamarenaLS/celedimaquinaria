<img src="<?php echo e($qrCodeDataUri); ?>" alt="Código QR">
<?php /**PATH C:\laragon\www\celeqr\resources\views/vista-qrcode.blade.php ENDPATH**/ ?>